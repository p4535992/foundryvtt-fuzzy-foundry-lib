export default function transformScore(result, data) {
  data.score = result.score
}
