# Backers

You can join them in supporting Fuse.js development by [pledging on Patreon](https://www.patreon.com/fusejs)! Backers in the same pledge level appear in the order of pledge date.

- Sam Corcos
- [Daniel Murawsky](https://github.com/dmurawsky) of [Urgos](https://urgos.io)
