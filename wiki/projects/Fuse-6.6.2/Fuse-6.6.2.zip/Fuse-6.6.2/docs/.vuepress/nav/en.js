module.exports = [
  { text: 'Guide', link: '/' },
  // { text: 'Blog', link: '/blog/' },
  // {
  //   text: 'Team',
  //   link: '/team/'
  // },
  {
    text: 'Sponsor',
    link: '/support/'
  },
  {
    text: 'Twitter',
    link: 'https://twitter.com/kirorisk'
  },
  {
    text: 'GitHub',
    link: 'https://github.com/krisk/Fuse'
  }
  // {
  //   text: 'Jobs',
  //   link: '/jobs/'
  // },
  // {
  //   text: 'Stories',
  //   link: '/stories/'
  // },
  // {
  //   text: 'Release Notes',
  //   link: 'https://github.com/krisk/Fuse/releases'
  // }
]
