const { path } = require('@vuepress/shared-utils')

module.exports = (options = {}, context) => ({
  extend: '@vuepress/theme-default'
})
