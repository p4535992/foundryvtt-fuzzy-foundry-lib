<template>
  <div class="donate-link-wrapper">
    <strong>❤️️ Fuse.js? Support its development with a small donation.</strong>
    <br />
    <a href="https://github.com/sponsors/krisk" class="donate-btn">Donate</a>
  </div>
</template>

<script>
export default {
  name: 'Donate'
}
</script>

<style>
.donate-link-wrapper {
  padding-top: 20px;
}

.donate-btn {
  display: inline-block;
  text-align: center;
  text-decoration: none;
  border: 0;
  cursor: pointer;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: antialiased;
  outline: 0;
  box-sizing: border-box;
  background: #9066b8;
  color: #fff;
  font-weight: 700;
  cursor: pointer;
  border-radius: 20px;
  margin: 20px 0 0 0;
  padding: 10px 30px;
}
.donate-btn:focus {
  outline: 0;
  text-decoration: none;
}
.donate-btn:hover {
  background-color: #a684c6;
  transition: background-color 250ms;
  text-decoration: none !important;
}
</style>
