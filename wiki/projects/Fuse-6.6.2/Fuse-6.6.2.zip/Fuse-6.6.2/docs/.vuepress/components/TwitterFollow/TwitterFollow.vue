<template>
  <div>
    <a
      href="https://twitter.com/kirorisk?ref_src=twsrc%5Etfw"
      class="twitter-follow-button"
      data-size="large"
      data-show-screen-name="false"
      data-dnt="true"
      data-show-count="false"
      >Follow</a
    >
    <script
      async
      src="https://platform.twitter.com/widgets.js"
      charset="utf-8"
    ></script>
  </div>
</template>

<script>
export default {
  name: 'TwitterFollow'
}
</script>
